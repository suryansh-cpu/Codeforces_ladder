#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
int recurr(int a)
{
    if(a>0)
    {
        cout << a << " ";
        recurr(a-1);
    }
    cout << a << " "; 
}
signed main(){
    int a;
    cin >> a;
    recurr(a);
    return 0;
}
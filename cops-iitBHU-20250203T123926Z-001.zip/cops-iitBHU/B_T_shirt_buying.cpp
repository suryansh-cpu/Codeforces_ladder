// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// #define push_back pb
// using namespace std;
// multimap <int, pair<int,int>> product; 
// signed main(){
//     // int a = 900000000000000;
//     // // cout << a;
//     // vector <int> v;
//     // v.push_back(a);
//     // for(auto i : v)
//     // {
//     //     cout << i;
//     // }
//     int n;
//     cin >> n;
//     vector <int> price;
//     vector <int> one;
//     vector <int> two;
//     for(int i=0; i<n; i++)
//     {
//         int a;
//         cin >> a;
//         price.pb(a);
//     }
//     for (int i = 0; i < n; i++)
//     {
//         int front_color;
//         cin >> front_color;
//         // product[front_color].insert(price[i]);
//         one.pb(front_color);
//     }
//     for (int i = 0; i < n; i++)
//     {
//         int front_color;
//         cin >> front_color;
//         // product[front_color].insert(price[i]);
//         two.pb(front_color);
//     }
//     for (int i = 0; i < n; i++)
//     {
//         product[price[i]] = {one[i],two[i]};
//     }
//     int no_of_customer;
//     cin >> no_of_customer;
//     return 0;
// }
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
#define push_back pb
using namespace std;
signed main(){
    int n;
    cin >> n;
    vector <int> price(n);
    vector <int> front(n);
    vector <int> back(n);
    for (int i = 0; i < n; i++)
    {
        cin >> price[i];
    }
    for (int i = 0; i < n; i++)
    {
        cin >> front[i];
    }
    for (int i = 0; i < n; i++)
    {
        cin >> back[i];
    }
    multiset<pair<int,int>> front_color[4];
    multiset<pair<int,int>> back_color[4];
    for (int i = 0; i < n; i++)
    {
        front_color[front[i]].insert({price[i],i});
    }
    for (int i = 0; i < n; i++)
    {
        back_color[back[i]].insert({price[i],i});
    }
    int total_customer;
    cin >> total_customer;
    for (int j = 0; j < total_customer; j++)
    {
        int small=0;
        int input;
        cin >> input;
        int selectedPrice = -1, index = -1;
        if(front_color[input].size()) {
            auto it = front_color[input].begin();
            selectedPrice = (*it).first;
            index = (*it).second;
        }
        if(back_color[input].size()) {
            auto it = back_color[input].begin();
            if(selectedPrice == -1 || (*it).first < selectedPrice) {
                selectedPrice = (*it).first;
                index = (*it).second;
            }
        }
        cout << selectedPrice << " ";
        if(selectedPrice == -1)continue;
        front_color[front[index]].erase({selectedPrice, index});
        back_color[back[index]].erase({selectedPrice, index});
        // 3
        // 1 2 3
        // 3 1 3
        // 1 3 1
        // 1
        // 1
    }
    
    return 0;
}
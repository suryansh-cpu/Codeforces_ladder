#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
#define push_back pb
using namespace std;
signed main(){
    int a,b;
    cin >> a >> b;
    ((a*b)%2==0)?(cout << "Even"):(cout << "Odd");
    return 0;
}
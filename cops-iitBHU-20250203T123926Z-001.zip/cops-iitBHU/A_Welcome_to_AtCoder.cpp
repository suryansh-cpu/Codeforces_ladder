#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
#define push_back pb
using namespace std;
signed main(){
    int a,b,c;
    cin >> a >> b >> c;
    string s;
    cin >> s;
    cout << a+b+c << " " << s;
    return 0;
}
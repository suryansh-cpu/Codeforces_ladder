// // #include <bits/stdc++.h>
// // #define int long long int
// // #define endl "\n"
// // using namespace std;
// // signed main(){
// //     int n,q;
// //     cin >> n >> q;
// //     map < int , int > data;
// //     vector <int> inputs;
// //     for (int i = 0; i < q; i++)
// //     {
// //         int a,b;
// //         int total_sub=0;
// //         int total_unread=0;
// //         cin >> a >> b;
// //         if(a==1)
// //         {    
// //             inputs.push_back(b);
// //             if ((data.find(b)!=data.end()))
// //             {
// //                 data[data.find(b)]++; 
// //                 total_unread++;
// //                 cout << total_unread << endl;
// //             }
// //             else if ((data.find(b)==data.end()))
// //             {
// //                 data[b]++;
// //                 total_unread++;
// //                 cout << total_unread << endl;
// //         }    }
// //         if (a==2)
// //         {
// //             total_unread -= data[b];
// //             data[b]=0;
// //             cout << total_unread;
// //         }
// //         if (a==3)
// //         {
// //             for (int i = 0; i < b; i++)
// //             {
// //                 if (data[inputs[i]]!=0)
// //                 {
// //                     total_sub++;
// //                 }
// //                 else
// //                 {
// //                     continue;
// //                 }
                
// //             }
// //             total_sub=0;
// //             cout << total_unread-total_sub << endl;
// //         }
        
// //     }
// //     return 0;
// // }
// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// signed main(){
//     int n,q;
//     cin >> n >> q;
//     int counter=0;
//     map < int , vector<int> > location_storing;
//     for (int i = 1; i <= n; ++i) {
//         location_storing[i] = {}; // Initialize each key with an empty vector
//     }
//     vector <int> input;
//     vector <int> not_read;
//     int j=0;
//     for (int i = 0; i < q; i++)
//     {
//         int a,b;
//         cin >> a >> b;
//         if (a==1)
//         {
//             input.push_back(b);
//             j++;
//             not_read.push_back(j);
//             location_storing[b].push_back(j);
//             cout << not_read.size() << endl;
//         }
//         else if(a==2)
//         {
//             auto it = location_storing.find(b);
//             if(it != location_storing.end())
//             {
//                 for(int val : it->second)
//                 {
//                     if(input[val]!=0)
//                     {
//                         input[val]=0;
//                         not_read.erase(not_read.begin()+val);
//                     }
//                     else
//                     {
//                         continue;   
//                     }
                    
//                 }
//             }
//             cout << not_read.size() << endl;
//         }
//         else if(a==3)
//         {
//             // cout << "in a==3";
//             // int pointer = not_read.begin();
//             // auto it = not_read.begin();
//             // int it = 0;
//             if(counter > b)
//             {
//                 // cout << "counter : " << counter << "b : " << endl;
//                 continue;
//             }
//             else
//             {
//                 // cout << "IN ELSE";
//                 int value=0;
//                 counter=b;
//                 for(int k = b-1; k >= 0; k--)
//                 {
//                     // cout << "IN WHILE " << endl;
//                     if(not_read[k]>b)
//                     {
//                         cout << not_read.size() << endl; 
//                         break;
//                     }
//                     else
//                     {    input[b]=0;
//                         // ++it;
//                         not_read.erase(not_read.begin()+k);
//                     }    // it++;
//                 }
//                 // counter=b;
//                 // not_read.erase(not_read.begin(),not_read.begin()+value); 
//             }
//             cout << not_read.size() << endl;
//         }
//     } 
//     // for (const auto& pair : location_storing) {
//     //     cout << "application: " << pair.first << " locations: ";
//     //     for (int val : pair.second) {
//     //         cout << val << " ";
//     //     }
//     //     cout << endl;
//     // }
//     return 0;
// }
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
    // int n,q;
    // cin >> n >> q;
    // s.insert(1);
    // s.insert(2);
    // s.insert(1);
    // s.insert(1);
    // s.insert(6);
    // for (auto it : s)
    // {
    //     cout << it;
    // }
set <int> Sx;
vector <int> V[300050];
signed main(){
	int N, Q, i, t1, t2, c = 0;
	cin >> N >> Q;
	while (Q--) {
		cin >> t1 >> t2;
		if (t1 == 1) {
			c++;
			Sx.insert(c);
			V[t2].push_back(c);
		}
		if (t1 == 2) {
			for (auto it : V[t2]) Sx.erase(it);
			V[t2].clear();
		}
		if (t1 == 3) {
			while (!Sx.empty()) {
				auto it = Sx.begin();
				if (*it > t2) break;
				Sx.erase(it);
			}
		}
		cout << Sx.size() << endl;
	}
	return 0;
}
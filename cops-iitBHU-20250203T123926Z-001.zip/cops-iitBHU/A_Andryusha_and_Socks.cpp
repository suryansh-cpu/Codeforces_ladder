#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    vector <int> arr(n+1,0);
    int ans=0;
    int jawab = 0;
    for (int i = 0; i < 2*n; i++)
    {
        int a;
        cin >> a;
        if (arr[a]==0)
        {
            arr[a]=1;
            ans++;
        }
        else if(arr[a]==1)
        {
            jawab = max(jawab,ans);
            ans--;
        }
    }
    cout << jawab;
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    string name[n];
    map < string , int > M;
    for (int i = 0; i < n; i++)
    {
        cin >> name[i];
    }
    for (int i = 0; i < n; i++)
    {
        if (M.find(name[i])!=M.end())
        {
            M[name[i]]++;
            string putt = to_string(M[name[i]]);
            name[i] = name[i]+putt;
        }
        else
        {
            M[name[i]] = 0;
            name[i] = "OK";
        }
        
    }
    for (int i = 0; i < n; i++)
    {
        cout << name[i] << endl;
    }
    
    return 0;
}
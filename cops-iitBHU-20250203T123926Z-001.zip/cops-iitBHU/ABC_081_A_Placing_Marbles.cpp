#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
#define push_back pb
using namespace std;
signed main(){
    int a;
    cin >> a;
    int counter=0;
    if(a%10==1)
    {
        counter++;
        a=a/10;
    }
    else
    {
        a=a/10;
    }
    if(a%10==1)
    {
        counter++;
        a=a/10;
    }
    else
    {
        a=a/10;
    }
    if(a%10==1)
    {
        counter++;
        // a=a/10;
    }
    // else
    // {
    //     a=a/10;
    // }
    cout << counter;
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    vector <int> arr(n);
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    sort(arr.begin(),arr.end());
    // if (n==1)
    // {
    //     cout << "NO";
    // }
        int j=1;
        while (j<n)
        {
            if(arr[j]==arr[0])
                j++;
            else if(arr[j]!=arr[0])
            {
                cout << arr[j];
                return 0;
            }
            
        }
        cout << "NO";
    return 0;
}
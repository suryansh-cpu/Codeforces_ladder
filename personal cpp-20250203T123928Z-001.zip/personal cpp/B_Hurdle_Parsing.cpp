#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    string s;
    cin >> s;
    int len = s.length(),i=1;
    int a=0;
    if(len==1)
    {
        cout << "0";
    }
    else
        while(i<len)
        {
            if(s[i]=='|')
            {
                cout << a << " ";
                a=0;
                i++;
            }
            else
            {
                a++;
                i++;
            }
        }
    return 0;
}
// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// int found=0;
// bool search_2(string m, string query, int query_pos)
// {
//     int string_lenght=m.length();
//     // bool found=false;
//     for (int i = ((query_pos-3>=0)?query_pos-3:0); i < ((query_pos+3< string_lenght)?query_pos+3:string_lenght); i++)
//     {
//         for (int j = 0; j < 4; j++)
//         {
//             if (m[i+j]!=query[j])
//             {
//                 break;
//             }
//             else if (j==3)
//             {
//                 // found = i;
//                 return true;
//             }
//         }
        
//     }
//     if ((found >= ((query_pos-3>=0)?query_pos-3:0)) && found <= ((query_pos+3  < string_lenght)?query_pos+3:string_lenght))
//     {
//         return false;
//     }
//     else
//     {
//         return true;
//     }
//     // return false;
// }
// void search(string m, string query)
// {
//     int string_lenght=m.length();
//     // bool found=false;
//     for (int i = 0; i < string_lenght-3; i++)
//     {
//         for (int j = 0; j < 4; j++)
//         {
//             if (m[i+j]!=query[j])
//             0
//             {
//                 break;
//             }
//             else if (j==3)
//             {
//                 found = i;
//             }
//         }
        
//     }
// }
// signed main(){
//     int test_case;
//     cin >> test_case;
//     string queries="1100";
//     for (int i = 0; i < test_case; i++)
//     {
//         string s;
//         cin >> s;
//         search(s,"1100");
//         int string_lenght=s.length();
//         int num=0;
//         cin >> num;
//         string a=s;
//         for (int j = 0; j < num; j++)
//         {
//             int query_position;
//             int query;
//             cin >> query_position;
//             cin >> query;
//             if(query==0)
//                 a[query_position-1] = '0';
//             else
//             {
//                 a[query_position-1] = '1';
//             }
            
//             // cout << a << endl;
//             if(search_2(a,"1100",query_position))
//             {
//                 cout << "YES" << endl;
//             }
//             else
//             {
//                 cout << "NO" << endl;
//             }
            
//         }   
//     }
//     return 0;
// }
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;

// Function to check if "1100" exists around query position
bool search_2(string m, string query, int query_pos) {
    int string_length = m.length();
    // Adjust the search range within the bounds of the string
    int start = max(0LL, query_pos - 4);
    int end = min(string_length - 4, query_pos + 3);

    for (int i = start; i <= end; i++) {
        bool match = true;
        for (int j = 0; j < 4; j++) {
            if (m[i + j] != query[j]) {
                match = false;
                break;
            }
        }
        if (match) return true; // Found "1100" in the range
    }
    return false;
}

// Initial search function to check if "1100" is present in the initial string
bool search(string m, string query) {
    int string_length = m.length();
    for (int i = 0; i <= string_length - 4; i++) {
        bool match = true;
        for (int j = 0; j < 4; j++) {
            if (m[i + j] != query[j]) {
                match = false;
                break;
            }
        }
        if (match) return true; // Found "1100"
    }
    return false;
}

signed main() {
    int test_case;
    cin >> test_case;
    string queries = "1100";

    for (int i = 0; i < test_case; i++) {
        string s;
        cin >> s;

        bool found_initially = search(s, "1100");
        int string_length = s.length();
        int num = 0;
        cin >> num;
        string a = s;

        for (int j = 0; j < num; j++) {
            int query_position, query;
            cin >> query_position >> query;

            // Update the character at query_position based on the input
            a[query_position - 1] = (query == 0 ? '0' : '1');

            // Check if "1100" appears around the modified position
            if (search_2(a, "1100", query_position - 1)) {
                cout << "YES" << endl;
            } else {
                cout << "NO" << endl;
            }
        }
    }
    return 0;
}

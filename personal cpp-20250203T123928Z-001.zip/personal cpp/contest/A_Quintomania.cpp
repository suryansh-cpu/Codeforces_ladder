#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int arr[n]={0};
        for (int j = 0; j < n; j++)
        {
            cin >> arr[j];
        }
        for (int j = 1; j < n; j++)
        {
            if (j==n-1)
            {
                if (abs(arr[j]-arr[j-1])==5 || abs(arr[j]-arr[j-1])==7)
                {
                    cout << "YES" << endl;
                }   
                else
                {
                    cout << "NO" << endl;
                }
            }
            else
            {
                if (abs(arr[j]-arr[j-1])==5 || abs(arr[j]-arr[j-1])==7)
                {
                    continue;
                }
                else
                {
                    cout << "NO" << endl;
                    break;
                }
                
            }
            
            
        }
        
    }
    
    return 0;
}
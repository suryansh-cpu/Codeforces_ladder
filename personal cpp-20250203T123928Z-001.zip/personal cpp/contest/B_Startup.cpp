// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// bool comp (int a, int b) {
//   return a > b;
// }
// signed main(){
//     int t;
//     cin >> t;
//     for (int i = 0; i < t; i++)
//     {
//         // cout << "###########################";
//         // cout << "Test case : " << i << endl;
//         int shelves;
//         int number_of_bottles;
//         cin >> shelves >> number_of_bottles;
//         int brand,costs;
//         vector <int> cost(number_of_bottles,0);
//         int unique=0;
//         // memset(cost,0,sizeof(cost));
//         for (int j = 0; j < number_of_bottles; j++)
//         {
//             cin >> brand >> costs;
//             // cout << "PRocessing bottle - " << j <<   " brand, cost" << brand << " " << costs << endl;
//             if (cost[brand-1]==0)
//             {
//                 unique++;
//             }
//             cost[brand-1]+=costs;
//         }
//         sort(cost.begin(),cost.end(),comp);
//         int total_cost=0;
//         for (int j = 0; j < ((shelves>unique)?unique:shelves); j++)
//         {
//             // cout << "Adding the cost for the " << j << endl;
//             total_cost += cost[j];
//         }
//         cout << total_cost << endl;
//         // cout << "###########################";
//     }
    
//     return 0;
// }

//  ####################### method - 2 ########################## using map @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int test_case;
    cin >> test_case;
    for (int i = 0; i < test_case; i++)
    {
        map <int, int> machine;
        int n,k;
        int brand,cost;
        cin >> n >> k;
        for (int j = 0; j < k; j++)
        {
            cin >> brand >> cost;
            machine[brand]+=cost;
        }
        int size_of_machine = machine.size();
        vector <int> arr(size_of_machine,0);
        map<int,int>::iterator it=machine.begin();
        for (int j = 0; j < size_of_machine; j++)
        {
            arr[j]=(it->second);

            it++;
        }
        sort(arr.begin(),arr.end(),greater<>());
        int total_cost=0;
        for (int j = 0; j < ((n>size_of_machine)?size_of_machine:n); j++)
        {
            total_cost=total_cost + arr[j];
        }
        cout << total_cost << endl;
        // cout << INT64_C(0) << endl;
    }
    
    return 0;
}
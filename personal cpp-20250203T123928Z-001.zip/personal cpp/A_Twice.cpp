#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int length;
        cin >> length;
        int v[length]={0};
        for (int j = 0; j < length; j++)
        {
            cin >> v[j];
        }
        int counter=0;
        int num=0;
        while (counter>length)
        {
            int a = v[counter];
            for (int j = counter+1; j < length; j++)
            {
                if (a==v[j])
                {
                    v[j]=-1;
                    v[counter]=-1;
                    num++;
                    break;
                }
            }
            counter++;
        }
        cout << num << endl;
    }
    return 0;
}
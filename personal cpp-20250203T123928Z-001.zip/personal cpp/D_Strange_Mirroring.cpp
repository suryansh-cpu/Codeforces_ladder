#include <bits/stdc++.h>
using namespace std;

// Function to find the character at position K after 10^100 transformations
char findCharacter(const string& S, long long K) {
    long long n = S.size();

    // Work backward to trace the position
    while (K > n) {
        if (K <= n * 2) {
            // If K is in the second half (T part), adjust to the corresponding position in S
            K = (K - n - 1) % n + 1;
        }
        // Otherwise, keep reducing until we reach the original size
    }

    // Return the character in the original string
    return S[K - 1];
}

int main() {
    // Input the original string S
    string S;
    cin >> S;
    int Q;
    cin >> Q;
    while (Q--) {
        long long K;
        cin >> K;
        cout << findCharacter(S, K) << '\n';
    }

    return 0;
}

#include <iostream>
#include <string>
using namespace std;

int main() {
    int N;
    cin >> N;
    string N_str = to_string(N);
    int count_1 = 0, count_2 = 0, count_3 = 0;
    for (char digit : N_str) {
        if (digit == '1') count_1++;
        else if (digit == '2') count_2++;
        else if (digit == '3') count_3++;
    }
    if (count_1 == 1 && count_2 == 2 && count_3 == 3) {
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }

    return 0;
}

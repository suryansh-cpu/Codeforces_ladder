#include <bits/stdc++.h>
using namespace std;
int main(){
    string petya;
    int n;
    cin >> petya;
    char array[12] ={'A','a','E','e','I','i','O','o','U','u','Y','y'};
    for (int j = 0; j < 12; j++)
    {
        petya.erase(remove(petya.begin(), petya.end(), array[j]), petya.end());
    }
    
    n = petya.size();
    for (int i = 0; i < n; i++)
    {
        if (petya[i] >= 'a' && petya[i] <= 'z')
        {
            continue;
        }
        else if (petya[i] >= 'A' && petya[i] <= 'Z')
        {
            int difference;
            difference = 'Z' - (petya[i]);
            petya[i] = 'z' - difference;
        }
    }
    int m;
    m = petya.size();
    for (int k = 0; k < m; k++)
    {
        cout << "." << petya[k];
    }
    
    return 0;
}
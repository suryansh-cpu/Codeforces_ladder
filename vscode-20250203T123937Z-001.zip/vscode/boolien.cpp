#include <bits/stdc++.h>
using namespace std;
    bool sum(int x, int y)
    {
        return x+y;
    }
int main()
{
    int a,b;
    cin >> a >> b;
    if (sum(a,b) != 1)
    {
        cout << "yes";
    }
    else
    cout << "no";
    
    return 0;
}
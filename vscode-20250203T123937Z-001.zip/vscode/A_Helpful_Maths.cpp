#include <bits/stdc++.h>
using namespace std;
int main(){
    int n=0,a=0,b=0,c=0;
    string s;
    cin >> s;
    n = s.size();
    for (int i = 0; i < n; i++)
    {
        if ( s[i] == '1' )
        {
            a = a + 1;
        }
        else if ( s[i] == '2' )
        {
            b = b + 1;
        }
        else if ( s[i] == '3')
        {
            c = c + 1;
        }
        
    }
    string answer;
    // -> 1+++2+3
    for (int j = 0; a + b + c > 0; j++)
    {
        if (a>0)
        {
            answer += "1+";
            a=a-1;
            continue;
        }
        else if (b>0)
        {
            answer += "2+";
            b=b-1;
            continue;
        }
        else if (c>0)
        {
            answer += "3+";
            c=c-1;
            continue;
        }
    }
    answer.pop_back();
    cout << answer << endl;
    return 0;
}

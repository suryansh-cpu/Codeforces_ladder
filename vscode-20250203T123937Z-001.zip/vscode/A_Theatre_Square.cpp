#include <bits/stdc++.h>
using namespace std;
int main(){
    long long int n,m,a,b,c;
    long long int d;
    cin >> n >> m >> a;
    b = (n + a - 1)/a; 
    c = (m + a - 1)/a;
    d = ((long long int)b)*((long long int)c);
    cout << d;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
// vector<> a;
// vector<int> a(n, 0);
// -> Element add, remove, access, total element count
// -> a.push_back(element_value);
// -> a.pop_back();
// -> a.pop_back(i);
// -> a[i] -> (i+1)th element
// -> a.size()


int main(){
    int n=0,k=0, b = 0 ,d=k;
    cin >> n >> k;
    vector<int> a;
    for (int i = 0; i < n; i++)
    {
        int m;
        cin >> m;
        a.push_back(m);
    }   
    b = a[k - 1]
    for(int i = k; i < n; i++) {
        if (a[i] >= b)
        {
            d += 1;
        }
    }
        cout << d;
    return 0;
}
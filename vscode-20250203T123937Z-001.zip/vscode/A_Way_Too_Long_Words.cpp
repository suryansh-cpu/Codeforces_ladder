#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    for ( int i = 0; i <= n ; i++)
    {
        string s;
        cin >> s;
        int character_count = s.size();
        if (character_count > 10) {
            cout << s[0] << character_count - 2 << s[character_count - 1] << endl;
        } else {
            cout << s << endl;
        }
    }
    
}
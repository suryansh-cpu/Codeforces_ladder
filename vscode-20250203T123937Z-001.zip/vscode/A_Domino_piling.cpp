#include <bits/stdc++.h>
using namespace std; int main(){
    int m,n,a,b;
    cin >> m >> n;
    a=m*n;
    b=a/2;
    cout << b;
    return 0;
}
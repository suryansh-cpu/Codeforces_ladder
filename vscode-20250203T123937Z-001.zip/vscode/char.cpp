#include <bits/stdc++.h>
using namespace std;
int main(){
    char a[15];
    cin >> a;
    cout << a;
    return 0;
}
#include <bits/stdc++.h>
using namespace std; 
int main(){
    string first;
    string second;
    cin >> first;
    cin >> second;
    int n = first.size();
    for(int i = 0; i < n; i++) {
        if (first[i] >= 'A' && first[i] <= 'Z') {
            first[i] = 'a' + (first[i] - 'A');
        }
        if (second[i] >= 'A' && second[i] <= 'Z') {
            second[i] = 'a' + (second[i] - 'A');
        }
    }
    int answer = 0;
    for(int i= 0; i < n; i++ ){ 
        if (first[i] == second[i]) continue;
        if (first[i] < second[i]){
            answer = -1;
            break;
        }
        answer = 1;
        break;
    }
    cout << answer;
    return 0;
}

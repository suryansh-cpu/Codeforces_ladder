#include <bits/stdc++.h>
using namespace std; 
int main(){
    int n=0,a=0;
    string m;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> m;
        if (m == "++X" || m == "X++")
        {
            a=a+1;
        }
        else if (m == "--X" || m == "X--")
        {
            a=a-1;
        }
    }
    cout << a;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main(){
    int number_question,mark1,mark2,mark3,correct_answer=0;
    cin >> number_question;
    for ( int i = 0; i < number_question ; i++)
    {
        cin >> mark1 >> mark2 >> mark3;
        if (mark1+mark2+mark3 >= 2)
        {
            correct_answer = correct_answer + 1;
        }
        
        }
        cout << correct_answer;
        return 0;
}
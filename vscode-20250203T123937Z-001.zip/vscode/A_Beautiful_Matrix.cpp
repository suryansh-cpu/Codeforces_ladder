#include <bits/stdc++.h>
using namespace std; 
int main(){
    int a[5][5],b=0,c=0;
    // n * m -> input -> n rows input where m values are in each row
    // vector<vector<int>> a(n, vector<int>(m, 0));
    // vector<vector<int>> a;
    // for(int i = 0; i < n; i++)
    // {vector<int> b;for(int j= 0; j < m; j++)
    // {cin >> k; b.push_back(k)}
    // a.push_back(b);}
    // n * m -> a input
    // a[i] -> ith row
    // a[i][j] -> ith row jth column
    // -> _ _ _ _ _
    for (int row = 0; row < 5; row++)
    {
        for (int column = 0; column < 5; column++)
        {
            cin >> a[row][column];
            if (a[row][column]==1)
            {
                if (row<=2)
                {
                    b=2-row;
                }
                else if (row>2)
                {
                    b=row-2;
                }
                if (column<=2)
                {
                    c=2-column;
                }
                else if (column>2)
                {
                    c=column-2;
                }
                
            }
            
        }
        
    }
    cout << b+c;
    return 0;
}
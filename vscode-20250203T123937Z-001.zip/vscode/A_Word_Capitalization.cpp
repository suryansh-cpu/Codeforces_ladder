#include <bits/stdc++.h>
using namespace std;
int main(){
    string n;
    string answer;
    int difference;
    cin >> n;
    if (n[0]>='A' && n[0]<='Z')
    {
       cout << n;
    }
    else {
    difference = 'z' - (n[0]);
    n[0] = 'Z' - difference;
    cout << n;}
    return 0;
}

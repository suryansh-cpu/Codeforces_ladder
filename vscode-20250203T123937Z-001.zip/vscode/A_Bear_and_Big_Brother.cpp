#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b,c=0;
    cin >> a >> b;
    if (a == b)
    {
        cout << 1;
    }
    if (a < b)
    {
    for(int i=0 ; a <= b ; i++ )
    {
        a = a*3;
        b = b*2;
        //c=i;
        c=c+1;
    }
    cout << c;
    }
    return 0;
}


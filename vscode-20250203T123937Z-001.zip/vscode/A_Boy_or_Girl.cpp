#include <bits/stdc++.h>
using namespace std;
int main()
{
    int count=0;
    string name;
    cin >> name;
    int n = name.size();
    for (int i = 0; i <= n; i++)
    {
        for (int j = 0; j <= n; j++)
        {
            if (i != j && name[i] == name[j])
            {
                //name.erase(j);
                count = count + 1;
            }
        }

    }
    int b;
    b = n - count;
    //b = name.size();
    if (b%2 == 0)
    {
        cout << "CHAT WITH HER!";
    }
    else
    {
        cout << "IGNORE HIM!";
    }
    return 0;
}

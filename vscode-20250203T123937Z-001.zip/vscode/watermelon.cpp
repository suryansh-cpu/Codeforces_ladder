#include <bits/stdc++.h>
using namespace std;
int main()
{
    int wm,b;
    cin >> wm;
    b = wm-2;
    if(wm%2 == 0 && b%2 == 0 && wm>=4){
        cout << "YES";
    }
    else
    cout << "NO";
    return 0;
}
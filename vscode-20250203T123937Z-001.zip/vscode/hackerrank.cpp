#include <bits/stdc++.h>
using namespace std;

int main() {
    int a;
    long int b;
    char c;
    float d;
    float e;
    cin >> a >> b >> c >> d >> e;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cout << d << endl;
    cout << e << endl;
    return 0;
}3 12345678912345 a 334.23 14049.30493

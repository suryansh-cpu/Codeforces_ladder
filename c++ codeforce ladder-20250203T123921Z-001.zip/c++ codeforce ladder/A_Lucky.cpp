#include <bits/stdc++.h>
#define endl "\n"
#define int long long int
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        string a;
        cin >> a;
        int c=a[0]+a[1]+a[2];
        int d=a[3]+a[4]+a[5];
        if (c==d)
        {
            cout << "YES" << endl;
        }
        else
        {
            cout << "NO" << endl;
        }
        
    }
    
    return 0;
}
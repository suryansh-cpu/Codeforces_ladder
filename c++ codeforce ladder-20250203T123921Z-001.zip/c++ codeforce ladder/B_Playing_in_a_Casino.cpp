#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n,m;
        cin >> n >> m;
        vector <vector <int>> v(n, vector <int> (m));
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < m; k++)
                {
                    cin >> v[j][k];
                }
        }
        int sum=0;
        for (int j = 0; j < n-1; j++)
        {
            for (int k = j+1; k < n; k++)
            {
                for (int l = 0; l < m; l++)
                {
                    sum += abs(v[j][l]-v[k][l]);
                }
                
            }
            
        }
        cout << sum << endl;
    }
    
    return 0;
}
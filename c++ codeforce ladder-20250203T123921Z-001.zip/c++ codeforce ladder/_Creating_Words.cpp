#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        string a,b;
        cin >> a >> b;
        char c = a[0];
        a[0]=b[0];
        b[0]=c;
        cout << a << " " << b << endl;
    }
    
    return 0;
}
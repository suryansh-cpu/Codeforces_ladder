#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    vector <int> v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    int count=0;
    sort(v.begin(),v.end());
    for (int i = n-2; i >= 0; i--)
    {
        if (v[i]!=v[n-1])
        {
            count+=v[n-1]-v[i];
        }
        
    }
    cout << count;
    return 0;
}
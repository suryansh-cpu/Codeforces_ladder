#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
int sign(int a)
{
    if(a>0)return 1;
    else if(a==0)return 0;
    else return -1;
}
signed main(){
    int x,y;
    cin >> x >> y;
    int sum= abs(x)+abs(y);
    if(sum*sign(x)<0)
    cout << sum*sign(x) << " " << "0" << " " << "0" << " " << sum*sign(y); 
    else cout << "0" << " " << sum*sign(y) << " " << sum*sign(x) << " " << "0"; 
    return 0;
}
// #include <bits/stdc++.h>
// #define endl "\n"
// //#define int long long int
// using namespace std;
// signed main(){
//     int n;
//     cin >> n;
//     vector <int> v(30, 0);
//     vector<int>::iterator it;
//     // vector <int> iterator it;
//     for (int i =1; i < 30; i++)
//     {
//         v[i]=pow(2,i);
//     }
//     for (int i = 0; i < 30; i++)
//     {
//         if (n==v[i])
//         {
//             cout << "1";
//             return 0;
//         }
        
//     }    
//     for (int i = 0; i < 30; i++)
//     {
//         if (n>=v[i] && n<=v[i+1])
//         {
//             int mid=(v[i+1]+v[i])/2;
//             if(n>=mid)
//             {
//                 cout << i+1;
//             }
//             else
//             {
//                 cout << i;
//             }
            
//         }
        
//     }    
//     return 0;
// }
#include <bits/stdc++.h>
#define endl "\n"
#define int long long int
using namespace std;
signed main(){
    int n;
    cin >> n;
    int count=1;
    while (n!=1)
    {
        if (n%2!=0)
        {
            count++;
            n-=1;
            n=n/2;
        }
        else
        {
            n=n/2;
        }
        
    }
    cout << count;
    return 0;
}
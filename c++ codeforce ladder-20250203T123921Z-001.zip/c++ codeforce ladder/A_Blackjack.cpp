#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    if (n<=10 || n>=22)
    {
        cout << "0";
    }
    else
    {
        if ((n>=11 && n<=19)||(n==21))
        {
            cout << "4";
        }
        else if(n==20)
        {
            cout << "15";
        }
        
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n,k;
        cin >> n >> k;
        int ans=0;
        int leaves_died=0;
        if(k<n)
        {
            leaves_died=abs(k-n);
            for (int j = leaves_died+1; j <= n; j++)
            {
                ans+=pow(j,j);
            }
        }
        else if(k>=n)
        {
            for (int j = 1; j <= n; j++)
            {
                ans+=pow(j,j);
            }
            
        }
        if (ans%2==0)
        {
            cout << "YES" << endl;
        }
        else
        {
            cout << "NO" << endl;
        }
        
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int test_cases;
    cin >> test_cases;
    for (int i = 0; i < test_cases; i++)
    {
        int a,b,c;
        cin >> a>> b>>c;
        if (a==b)
        {
            cout << c << endl;
        }
        else if (b==c)
        {
            cout << a << endl;
        }
        else
        {
            cout << b << endl;
        }
        
        
    }
    
    return 0;
}
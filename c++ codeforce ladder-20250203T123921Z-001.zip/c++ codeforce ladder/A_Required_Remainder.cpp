#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for(int j=0;j<t;j++)
    {
        int x=0,y=0,n=0,ans=0;
        cin >> x >> y >> n;
        ans = n/x;
        ans = ans*x;
        if (ans+y<=n)
        {
            cout << ans+y << endl;
        }
        else
        {
            cout << ans-(x-y) << endl;
        }
    }
    return 0;
}
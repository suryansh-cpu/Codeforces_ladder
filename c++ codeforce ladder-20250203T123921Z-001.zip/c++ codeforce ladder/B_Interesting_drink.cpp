#include <bits/stdc++.h>
#define endl "\n"
#define int long long int
using namespace std;
signed main(){
    int shops;
    cin >> shops;
    vector <int> prices(shops);
    for (int i = 0; i < shops; i++)
    {
        cin >> prices[i];
    }
    sort(prices.begin(),prices.end());
    int days;
    cin >> days;
    vector <int> coins(days);
    int a[100001]={0};
    for (int i = 0; i < shops; i++)
    {
        a[prices[i]]++;
    }
    int p[100001]={0};
    for (int i = 1; i < 100001; i++)
    {
        p[0]=a[0];
        if(i>=1)
        {
            p[i]=p[i-1]+a[i];
        }
        
    }
    for (int i = 0; i < days; i++)
    {
        cin >> coins[i];
        if(coins[i]>100000)
        {
            cout << shops << endl;            
        }
        else{
        cout << p[coins[i]] << endl;
        }
    }
    
    return 0;
}
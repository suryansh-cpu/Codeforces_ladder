#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a;
    cin >> a;
            for (int j = 0; j < 1; j++)
            {
                if (a[j] >= 'a' && a[j] <= 'z')
                {
                    a[j] = a[j] - 32;
                    break;
                }
                else 
                {
                    break;
                }
            }
            cout << a;
        return 0;
}
/*method 1-->
upper case = x = x-32
lower case = x = x+32
method 2-->
toupper*/
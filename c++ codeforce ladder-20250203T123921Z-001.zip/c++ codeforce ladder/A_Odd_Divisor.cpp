#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
bool check(int n)
{
    static int arr[46]={0};
    static bool initialized = false;
    bool ans=true;
    if(!initialized)
    {
        for (int i = 0; i < 46; i++)
        {
            arr[i]=pow(2,i+1);
        }
        initialized=true;
    }
    for (int i = 0; i < 46; i++)
    {
        if (n==arr[i])
        {
            ans=false;
        }
        
    }
    return ans;
}
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        if (!check(n))
        {
            cout << "NO" << endl;
        }
        else
        {
            cout << "YES" << endl;
        }
        
    }
    
    return 0;
}
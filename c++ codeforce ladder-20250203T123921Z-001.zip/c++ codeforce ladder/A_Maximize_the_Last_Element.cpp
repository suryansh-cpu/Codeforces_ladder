#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        vector <int> input(n);
        for (int j = 0; j < n; j++)
        {
            cin >> input[j];
        }
        int maxi=0;
        for (int j = 0; j < n; j+=2)
        {
            maxi=max(maxi,input[j]);
        }
        cout << maxi << endl;
    }
    return 0;
}
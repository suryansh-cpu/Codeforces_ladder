#include <bits/stdc++.h>
using namespace std;
int main()
{
    int players;
    cin >> players;
    int counter;
    int len;
    for (int i = 0; i < len; i++)
    {
        for (int j = i+1; j < i+7; j++)
        {
            if (players[i]==players[j])
            {
                counter++;
                continue;
            }
            else if (players[i] != players[j])
            {
                counter = 0;
                break;
            }
            
        }
        if (counter != 0)
        {
            cout << "YES";
            return 0;
        }
        else
        {
            continue;
        }
        
    }
    cout << "NO";
    return 0;
}
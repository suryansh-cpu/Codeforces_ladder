#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int test_cases;
    cin >> test_cases;
    for (int i = 0; i < test_cases; i++)
    {
        int n,k;
        cin >> n >> k;
        int divisible=0;
        divisible = k/n;
        int ans=0;
        ans = k+divisible;
        while (divisible != ans/n)
        {
            divisible = (ans/n)-divisible;
            ans += divisible;
            divisible = ans- divisible;
            divisible/=n;
        }
        cout << ans << endl;
    }
    
    return 0;
}
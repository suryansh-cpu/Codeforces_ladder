#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int test_case;
    cin >> test_case;
    for (int i = 0; i < test_case; i++)
    {
        int n;
        cin >> n;
        // int num = n+1;
        // num = num/2;
        if(n==1)
        {
            cout << "Kosuke" << endl;
        }
        else
        {
            if (n%2==0)
            {
                cout << "Sakurako" << endl;
            }
            else
            {
                cout << "Kosuke" << endl;
            }
        }
        
        // else if(n==100)
        // {
        //     cout << "Sakurako" << endl;
        // }
        // else
        // {    
        //     if (num%2==0)
        //     {
        //         cout << "Kosuke" << endl;
        //     }
        //     else
        //     {
        //         cout << "Sakurako" << endl;
        //     }
        // }
    }
    
    return 0;
}
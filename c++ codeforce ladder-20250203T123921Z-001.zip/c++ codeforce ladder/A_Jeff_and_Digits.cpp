#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    int five=0;
    int zero=0;
    for (int i = 0; i < n; i++)
    {
        int a;
        cin >> a;
        if(a==5)five++;
        else zero++;
    }
    if(zero==0 && five<15)
    {
    cout << "-1";
    }
    else if(zero==0 && five>=15)
    for(int i=0;i<five;i++)
    cout << "5";
    else
    {
        if(five>=14)
        {
            for(int i=0;i<five;i++)
            {
                cout << "5";
            }
            for (int j = 0; j < zero; j++)
            {
                cout << "0";
            }
        }
        else if((five>9 && five<14) && five+zero<=13)
        {
            for(int i=0;i<9;i++)
            {
                cout << "5";
            }
            for (int j = 0; j < zero; j++)
            {
                cout << "0";
            }
        }
        else if((five>9 && five<14) && five+zero>=14)
        {
            for(int i=0;i<five;i++)
            {
                cout << "5";
            }
            for (int j = 0; j < zero; j++)
            {
                cout << "0";
            }
        }
        else cout << "0";
    }
    
    return 0;
}
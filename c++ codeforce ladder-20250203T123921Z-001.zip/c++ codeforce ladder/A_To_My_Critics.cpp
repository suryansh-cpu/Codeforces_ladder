#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int a,b,c;
        cin >> a >> b >> c;
        if(a+b>=10)
            cout << "YES" << endl;
        else if(c+b>=10)
            cout << "YES" << endl;
        else if(c+a>=10)
            cout << "YES" << endl;   
        else {
            cout << "NO" << endl;
        }
    }
    return 0;
}
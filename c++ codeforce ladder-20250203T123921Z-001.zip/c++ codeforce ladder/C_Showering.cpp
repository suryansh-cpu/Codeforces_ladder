#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n,s,m;
        cin >> n >> s >> m;
        int a,b=0;
        a=0;
        for (int j = 0; j < n; j++)
        {
            int one,two;
            cin >> one >> two;
            if (j==0)
            {
                if (one>=s)
                {
                    cout << "YES" << endl;
                    break;
                }
                else
                {
                    a=two;
                    continue;
                }
                
            }
            else
            {
                if (j==n-1)
                {
                    if (m-two>=s)
                    {
                        cout << "YES" << endl;
                        break;
                    }
                    else
                    {
                        cout << "NO" << endl;
                        break;
                    }
                }
                else
                {
                    if (one-a>=s)
                    {
                        cout << "YES" << endl;
                        break;
                    }
                    else
                    {
                        a=two;
                        continue;
                    }
                    
                }
                
            }
            
        }
        //cout << a << b << endl;
    }
    
    return 0;
}
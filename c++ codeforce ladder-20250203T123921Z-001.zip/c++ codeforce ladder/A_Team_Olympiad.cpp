#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    vector <int> number(t);
    vector <int> ::iterator it1;
    vector <int> ::iterator it2;
    vector <int> ::iterator it3;
    int one=0,two=0,three=0;
    for (int i = 0; i < t; i++)
    {
        cin >> number[i];
        if (number[i]==1)
        {
            one++;
        }
        else if (number[i]==2)
        {
            two++;
        }
        else
        {
            three++;
        }
    }
    int counter=0;
    int on=1,tw=2,thr=3;
    int minimum=min(one,min(two,three));
    cout << minimum << endl;
    for (int i = 0; i < t; i++)
    {
        it1=find(number.begin(),number.end(),on);
        it2=find(number.begin(),number.end(),tw);
        it3=find(number.begin(),number.end(),thr);
        if ((it1==number.end()||it2==number.end())||it3==number.end())
        {
            break;
        }
        else
        {
            cout << it1-number.begin()+1 << " " << it2-number.begin()+1 << " " << it3-number.begin()+1 << endl;
            number[it1-number.begin()]=0;
            number[it2-number.begin()]=0;
            number[it3-number.begin()]=0;
        }
        
        // if (it1!=number.end())
        // {
        //     cout << it-number.begin() << " ";
        // }
        // else
        // {
        //     break;
        // }
        
        // if (it2!=number.end())
        // {
        //     cout << it-number.begin() << " ";
        // }
        // else
        // {
        //     break;
        // }
        
        // if (it3!=number.end())
        // {
        //     cout << it-number.begin() << " ";
        // }
        // else
        // {
        //     break;
        // }
        //cout << "\n";
    }
    
    return 0;
}
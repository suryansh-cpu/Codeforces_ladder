#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        int qu;
        cin >> n;
        cout << n;
        cin >> qu;
        vector<vector<int>> array(n, vector<int>(n));
        for(int j=0;j<n;j++)
        {
            for(int k=0;k<n;k++)
            {
                cin >> array[j][k];
            }
        }
        qu=n/qu;
        int ans_1=0;
        for (int a = 0; a < qu; a++)
        {
            int one;
            for (int b = 0; b < qu,ans_1<n; b++,ans_1++)
            {
                one=array[a][b];
            }
            cout << one;
        }
        cout << endl;
        int ans_2=0;
        for (int a = qu; a < n; a++)
        {
            int one;
            for (int b = 0; b < qu,ans_1<n; b++,ans_2++)
            {
                one=array[a][b];
            }
            cout << one;
        }
        cout << endl;
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        string input;
        cin >> input;
        int a=input.size();
        //cout << a;
        for (int j = 0; j < a-2; j++)
        {
            if (input[j]==input[j+1])
            {
                input[j+1]=0;
                j++;
            }
            else
            {
                continue;
            }
        }
        for (int j = 0; j < a; j++)
        {
            if (input[j]!=0)
            {
                cout << input[j];
            }
            
        }
        cout << endl;
    }
    return 0;
}
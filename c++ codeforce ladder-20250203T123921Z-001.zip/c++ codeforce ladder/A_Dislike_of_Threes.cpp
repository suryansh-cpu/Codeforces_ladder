#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    int three[1000]={0};
    int i=1;
    // for (int i = 1; i <= 1000; i++)
    // {
        for (int j = 1; j <= 1667; j++)
        {
            if(i>1000)
            {
                break;
            }
            if (j%3==0 || j%10==3)
            {
              continue;   
            }
            else
            {
                three[i]=j;
                i++;
            }
            
        }
    // }
    
    for (int k = 0; k < n; k++)
    {
        int integer;
        cin >> integer;
        // if (integer%3==0 || integer%10==3)
        // {
        //     continue;
        // }
        // else
        // {
        //     cout << integer << endl;
        // }
        cout << three[integer] << endl;
    }
    return 0;
}
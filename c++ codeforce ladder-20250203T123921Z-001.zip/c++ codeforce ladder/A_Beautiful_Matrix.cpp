#include <bits/stdc++.h>
using namespace std;
int main()
{
    // 21012 for x
    // 21012 foy y
    // 21012 for z
    // 21012 for a
    // 21012 for b
    int x=0,y=0,z=0,a=0,b=0,c=0;
    for (int i = 0; i < 5; i++)
    {
        cin >> x >> y >> z >> a >> b;
        
    }
    return 0;
}
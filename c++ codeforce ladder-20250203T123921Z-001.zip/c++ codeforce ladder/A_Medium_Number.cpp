#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int a,b,c;
    int t;
    cin >> t;
    for(int i=0;i<t;i++)
    {
        //cin >> a >> b >> c;
        

        /*
            METHOD --> 1
        */

       
        // if ((a>=b && a<=c) ||(a<=b && a>=c))
        // {
        //     cout << a << endl;
        //     continue;
        // }
        // else if ((b>=a && b<=c)||(b>=c && b<=a))
        // {
        //     cout << b << endl;
        //     continue;
        // }
        // else if ((c>=b && c<=a)||(c>=a && c<=b))
        // {
        //     cout << c << endl;
        //     continue;
        // }


        /*
            METHOD --> 2
        */


        // if (a>=b && a>=c)
        // {
        //     if (b>=c)
        //     {
        //         cout << b << endl;
        //     }
        //     else
        //     {
        //         cout << c << endl;
        //     }
            
        // }
        // else if (b>=a && b>=c)
        // {
        //     if (a>=c)
        //     {
        //         cout << a << endl;
        //     }
        //     else
        //     {
        //         cout << c << endl;
        //     }
            
        // }
        // else if (c>=b && c>=a)
        // {
        //     if (a>=b)
        //     {
        //         cout << a << endl;
        //     }
        //     else
        //     {
        //         cout << b << endl;
        //     }
            
        // }
        


        /*
            METHOD --> 3
        */


       
       vector <int> a(3);
       for (int i = 0; i < 3; i++)
        cin >> a[i];
       sort(a.begin(),a.end());
       cout << a[1] << endl;
    }
    return 0;
}
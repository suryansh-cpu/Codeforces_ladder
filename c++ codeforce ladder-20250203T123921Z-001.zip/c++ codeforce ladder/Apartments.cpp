// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// signed main(){
//     int n,m,k;
//     cin >> n >> m >> k;
//     vector <int> req(n);
//     vector <int> available(m);
//     for (int i = 0; i < n; i++)
//     {
//         cin >> req[i];
//     }
//     for (int i = 0; i < m; i++)
//     {
//         cin >> available[i];
//     }
//     //sort(req.begin(),req.end());
//     sort(available.begin(),available.end());
//     for(int i=0;i<n;i++)
//     {
        
//     }
//     return 0;
// }


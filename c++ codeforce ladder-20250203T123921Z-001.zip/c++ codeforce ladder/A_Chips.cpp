#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n,m;cin >> n >> m;
    int i=1;
    while (i<=n)
    {
        if(i==n && m>i){m=m-i;i=1;}
        else if(m==i){cout << "0";break;}
        else if(m>i){m=m-i;i++;}
        else if(m<i){cout << m;break;}
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int j = 0; j < t; j++)
    {
        
        string real = "codeforces";
        string given;
        cin >> given;
        int counter=0;
        for (int i = 0; i < 10; i++)
        {
            if (real[i]==given[i])
            {
                continue;
            }
            else
            {
                counter++;
            }
            
        }
        cout << counter << endl;
    }
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main()
{
    string a;
    string b;
    cin >> a;
    cin >> b;
    string c;
    int d;
    d = a.length();
    for (int i = 0; i < d; i++)
    {
        if (a[i] == b[i])
        {
            c += '0';
            continue;
        }
        else if (a[i] != b[i])
        {
            c += '1';
            continue;
        }
        
    }
    cout << c;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int players;
    cin >> players;
    string a;
    int counter_team_a=0;
    int counter_team_b=0;
    string b;
    for (int i = 0; i < players; i++)
    {
        string c;
        cin >> c;
        if(i==0)
        {
            a=c;
            counter_team_a++;
        }
        else if (c==a)
        {
            counter_team_a++;
        }
        else if (c!=a)
        {
            b=c;
            counter_team_b++;
        }
        
    }
    (counter_team_a>counter_team_b)?(cout << a):(cout << b);
    return 0;
}
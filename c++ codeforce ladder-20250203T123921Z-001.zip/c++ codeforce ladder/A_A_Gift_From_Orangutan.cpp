#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int arr[n]={0};
        int max_pointer=0;
        int min_pointer=0;
        int max=0;
        int min=0;
        for (int j = 0; j < n; j++)
        {
            cin >> arr[j];
            if(j==0)
            {
                min=arr[j];
                max=arr[j];
                max_pointer=j;
                min_pointer=j;
            }
            else
            {
                if(arr[j]>max)
                {
                    max=arr[j];
                    max_pointer=j;
                }
                if(arr[j]<min)
                {
                    min=arr[j];
                    min_pointer=j;
                }
            }
            
        }
        int arr_b[n]={0};
        int arr_c[n]={0};
        for (int j = 0; j < 1; j++)
        {
            arr_b[j]=max;
        }
        for (int j = 1; j < n; j++)
        {
            arr_b[j]=min;
        }
        for (int j = 0; j < n; j++)
        {
            arr_c[j]=max;
        }
                            //              check            //

        // for (int j = 0; j < n; j++)
        // {
        //     cout << arr_b[j];
        // }
        // cout << endl;

        int sum=0;
        for (int j = 0; j < n; j++)
        {
            sum += (arr_c[j]-arr_b[j]);
        }
        cout << sum << endl;
    }
    
    return 0;
}
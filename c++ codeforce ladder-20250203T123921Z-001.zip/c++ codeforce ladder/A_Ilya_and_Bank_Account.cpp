#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
void large(int n)
{
    int a=n;
    int last_digit=abs(a%10);
    int second_last=abs((a/10)%10);
    if (second_last>=last_digit)
    {
        n=n/10;
        n=n+(second_last-last_digit);
        
        cout << n;
    }
    else
    {
        n=n/10;
        cout << n;
    }
    
}
signed main(){
    int n;
    cin >> n;
    if (n<0)
    {
        large(n);
    }
    else
    {
        cout << n;
    }
    
    return 0;
}
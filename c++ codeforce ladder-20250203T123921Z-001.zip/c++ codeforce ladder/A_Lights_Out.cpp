#include <bits/stdc++.h>
using namespace std;
int change(int &a)
{
    if (a == 0)
    {
        a = 1;
        //on
    }
    else if (a == 1)
    {
        a = 0;
        //off
    }
    return a;
}
int main()
{
    int input[3][3];//input leds;
    int output[3][3] = {1, 1, 1, 1, 1, 1, 1, 1, 1};// output leds;
    //memset(output, 0/-1, sizeof(output)); // fills array with 0 and -1 only
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cin >> input[i][j]
        }
    }
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            int a;
            a = input[i][j];
            if (a%2 == 0)
            {
                continue;
            }
                change(output[i][j]);
                if(j != 0)
                {
                    change(output[i][j-1]);
                }

                if(i != 0)
                {
                    change(output[i-1][j]);
                }
                if(i != 2)
                {
                    change(output[i+1][j]);
                }
                if( j != 2)
                {
                    change(output[i][j+1]);
                }

            
            
        }
        
    }
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout << output[i][j];
        }
        cout << "\n";
    }
    
    return 0;
}
// change(ol[i][j]);
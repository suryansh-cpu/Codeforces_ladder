#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    if (n<=3)
    {
        cout << "NO SOLUTION";
    }
    else{
    for (int i = 1; i <= n; i++)
    {
        cout << i << " ";
        i++;
    }
    for (int i = 2; i <= n; i++)
    {
        cout << i << " ";
        i++;
    }
    }
    return 0;
} 
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for(int j=0;j<t;j++)
    {
        int a;
        int b;
        cin >> a >> b;
        int ans=INT_MAX;
        for (int i = a; i <= b; i++)
        {
            if (((i-a)+(b-i))<ans)
            {
                ans = ((i-a)+(b-i));
            }
            
        }
        cout << ans << endl;
    }
    return 0;
}
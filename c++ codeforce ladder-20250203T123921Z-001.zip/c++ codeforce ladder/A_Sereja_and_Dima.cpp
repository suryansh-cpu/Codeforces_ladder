#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    vector <int> v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    int s=0,d=0;
    int a,b;
    a=n-1;
    b=0;
    for (int i = 0; i < n; i++)
    {
        if (i%2==0)
        {
            if (v[a]>=v[b])
            {
                s+=v[a];
                a--;
            }
            else
            {
                s+=v[b];
                b++;
            }
            
        }
        
        else if (i%2!=0)
        {
            if (v[a]>=v[b])
            {
                d+=v[a];
                a--;
            }
            else
            {
                d+=v[b];
                b++;
            }
        }
        
    }
    cout << s << " " << d;
    return 0;
}
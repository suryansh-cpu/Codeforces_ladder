// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// signed main(){
//     int n,k,count=0;
//     cin >> n >> k;
//     vector<vector <char>> a(n,vector <char> (k));
//     for(int i=0;i<n;i++)
//         for(int j=0;j<k;j++)
//             cin >> a[i][j];
//     for(int i=0;i<n;i++)
//         for(int j=0;j<k;j++)
//         {
//             if(a[i][j]=='S')break;
//             else if(j==k-1 && a[i][j]!='S')
//             {
//                 for(int x=i;x<i+1;x++)
//                     for(int y=0;y<k;y++)
//                         a[x][y]='e';
//             }
//             else continue;
//         }
//     for(int j=0;j<k;j++)
//         for(int i=0;i<n;i++)
//         {
//             if(a[i][j]=='S')break;
//             else if(i==n-1 && a[i][j]!='S')
//             {
//                 for(int x=j;x<j+1;x++)
//                     for(int y=0;y<n;y++)
//                         a[y][x]='e';
//             }
//             else continue;
//         }
//     for(int i=0;i<n;i++)
//         for(int j=0;j<k;j++)
//             if(a[i][j]=='e')
//             {
//                 count++;
//             }
//     cout << count;
//     return 0;
// }
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    
    return 0;
}
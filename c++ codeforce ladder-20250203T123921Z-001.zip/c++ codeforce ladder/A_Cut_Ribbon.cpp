#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b,c;
    int n;
    cin >> n;
    cin >> a >> b >> c;
    int ans = 0, max_length_cut_possible = 0;
    if (a==1 || b == 1 || c==1)
    {
        cout << n;
        return 0;
    }
    for (int i = 0; i <= n; i+=a)
    {
        for (int j = 0; j <= n; j+=b)
        {
            for (int k = 0; k <= n; k+=c)
            {
                int total_length_cut = i + j + k;
                if( total_length_cut <= n) {
                    if(total_length_cut > max_length_cut_possible) {
                        ans = i / a + j / b + k / c;
                        max_length_cut_possible = total_length_cut;
                    }
                    else if(total_length_cut == max_length_cut_possible) { 
                        ans = max(ans, i / a + j / b + k / c);
                    }
                }   
            }  
            // if (b==c)
            // {
            //     break;
            // }
        }
        // if (a==b)
        // {
        //     break;
        // }
    }
    cout << ans << endl;
    return 0;
}
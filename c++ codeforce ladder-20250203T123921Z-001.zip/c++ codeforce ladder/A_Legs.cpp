#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int a=0;
        a=n/4;
        int b=0;
        b=n-(a*4);
        int c=b/2;
        cout << a+c << endl;
    }
    
    return 0;
}
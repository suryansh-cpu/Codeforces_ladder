#include <bits/stdc++.h>;
using namespace std;
int main(){
    int t;
    cin >> t;
    for(int k=0;k<t;k++){
    string a;
    cin >> a;
    int leng;
    leng=a.size();
    int count=1;
    for (int i = 1; i < leng; i++)
    {
        if (a[i]=='0')
        {
            continue;
        }
        else
        {
            count++;
            continue;
        }
    }
    cout << count << "\n";
    for (int i = 0; i < leng; i++)
    {
        int number=0;
        number=leng-(i+1);
        if (a[i]=='0')
        {
            continue;
        }
        else
        {
            int f=10;
            f = pow(10.0,number);
            
            //cout << "F=" << f << "\n";
            
            //f *= number;
            
            int g=a[i]-48;
            
            //cout << "G =" << g << "\n";
            
            g=g*f;
            cout << g << " ";
        }
        
    }
    cout << "\n";
    }
    return 0;
}
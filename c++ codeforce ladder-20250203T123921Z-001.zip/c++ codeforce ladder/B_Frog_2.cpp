#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
int t[100002];
using namespace std;
signed main(){
    int n;
    cin >> n;
    int jump;
    cin >> jump;
    vector <int> v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    memset(t,-1,sizeof(t));
    t[n-1]=0;
    
    return 0;
}
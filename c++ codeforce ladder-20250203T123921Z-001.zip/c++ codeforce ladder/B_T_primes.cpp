// #include <bits/stdc++.h>
// //#define int long long 
// using namespace std;
// int main(){
//     int n;
//     cin >> n;
//     int x=1000000;
//     int is_prime[x];
//     fill(is_prime, is_prime+x, 1);
//     for (long long int i = 2; i <= sqrt(x); i++)
//     {
//         if (is_prime[i])
//         {
//             for (long long int j = i*i; j <= x; j+=i)
//             {
//                 is_prime[j]=0;
//             }
            
//         }
        
//     }
//     for (int j = 0; j < n; j++)
//     {
//         long long int a=0;
//         cin >> a;
//         int exit=sqrt(a);
//         if (is_prime[exit])
//         {
//             cout << "YES" << endl;
//         }
//         else if (!is_prime[exit])
//         {
//             cout << "NO" << endl;
//         }
        
//     }
//     // for (int i = 0; i < n; i++)
//     // {
//     //     int count=0;
//     //     if ((a[i]%10)%2==0 && a[i]>10)
//     //         {
//     //             //count=3;
//     //             cout << "NO" << "\n";
//     //             continue;
//     //         }
//     //         if (a[i]==4)
//     //         {
//     //             cout << "YES" << "\n";
//     //             continue;
//     //         }
//     //     for (int j = 3; j <= sqrt(a[i]+1); j+=2)
//     //     {
//     //         if(a[i]%2==0 && a[i]!=4)
//     //         {
//     //             //count++;
//     //             count = 0;
//     //             //cout << "NO" << "\n";
//     //             break;
//     //         }    
//     //         if (a[i]%j==0)
//     //         {
//     //             count++;
//     //             continue;
//     //         }   
//     //     }
//         // if (count==0)
//         // {
//         //     cout << "NO" << "\n";
//         // }
        
//         // if (count>=2)
//         //     {
//         //         cout << "NO" << "\n";
//         //         //break;
//     //     //     }
//     //     if (count==1)
//     //     {
//     //         cout << "YES" << "\n";
//     //     }
//     //     else
//     //     {
//     //         cout << "NO" << "\n";
//     //     }
        
//     // }
//     // for (int i = 0; i < n; i++)
//     // {
//     //     cout << a[i];
//     // }
//     return 0;
// }
#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    int x = 10000000;
    int is_prime[x + 1];
    fill(is_prime, is_prime + x + 1, 1);
    is_prime[0] = is_prime[1] = 0; // 0 and 1 are not prime numbers

    // Sieve of Eratosthenes
    for (long long int i = 2; i <= sqrt(x); i++) {
        if (is_prime[i]) {
            for (long long int j = i * i; j <= x; j += i) {
                is_prime[j] = 0;
            }
        }
    }

    for (int j = 0; j < n; j++) {
        long long int a;
        cin >> a;
        int exit = sqrt(a);
        if (exit * exit != a) { // Check if 'a' is a perfect square
            cout << "NO" << endl;
        } else if (exit <= x && is_prime[exit]) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }

    return 0;
}

#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    int m;
    cin >> m;
    vector <int> v(m);
    for (int i = 0; i < m; i++)
    {
        cin >> v[i];
    }
    int i=1;
    long long int count=0;
    for (int j = 0; j < m; j++)
    {
        if (j==0)
        {
            count+=v[j]-1;
        }
        else if (v[j]>=v[j-1])
        {
            count = count + v[j]-v[j-1];
        }
        else if (v[j]<v[j-1])
        {
            count = count + (n-v[j-1]) + v[j];
        }
        
    }
    cout << count;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main(){
    int rides,m_rides,one_ticket,m_ticket;
    cin >> rides >> m_rides >> one_ticket >> m_ticket;
    int d;
    d=(rides/m_rides);
    int e=rides-(d*m_rides);
    int answer1=d*m_ticket+e*one_ticket;
    int answer2=rides*one_ticket;
    int answer3=(d+1)*m_ticket;
    cout << min(answer1,min(answer2,answer3));
    return 0;
}
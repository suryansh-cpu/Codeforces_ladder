#include <bits/stdc++.h>
//#define int long long int
#define endl "\n"
using namespace std;
int main(){
    int n;
    cin >> n;
    string name="codeforces";
    for (int i = 0; i < n; i++)
    {
        char a;
        cin >> a;
        for (int j = 0; j < 10; j++)
        {
            if (a==name[j])
            {
                cout << "YES" << endl;
                break;
            }
            if (j==9 && name[j]!=a)
            {
                cout << "NO" << endl; 
            }
            
        }
    }
    
    return 0;
}

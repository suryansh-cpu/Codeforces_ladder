//method 1
//unique approach
#include <cstdio>
 
bool good(int n)
{
	int dig[10] = {0};
	while (n)
	{
		dig[n%10]++;
		if (dig[n%10] > 1) return false;
		n /= 10;
	}
	return true;
}
 
int main()
{
	int n;
	scanf("%d", &n);
	int m = n+1;
	while (!good(m)) ++m;
	printf("%d\n", m);
}

/*method 2
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int year;
    cin >> year;
    int a,b,c,d;
   for (int i = 1; i > 0; i++)
   {
    year = year + 1;
    a = year/1000;
    b = year/100-a*10;
    c = year/10-a*100-b*10;
    d = year%10;
    if ((a != b && a != c) && a !=d)
    {
        if (b != c && b !=d)
        {
            if (c != d)
            {
                break;
            }
            else
            {
                continue;
            }
            
        }
        else
        {
            continue;
        }
    }
    else
    {
        continue;
    }
   }
   cout << year;
    return 0;
}
*/

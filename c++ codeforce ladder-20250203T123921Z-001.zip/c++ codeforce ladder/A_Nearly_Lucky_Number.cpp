#include <bits/stdc++.h>
using namespace std;
int main()
{
    string n;
    int c=0;
    cin >> n;
    int a;
    a = n.size();
    for (int i = 0; i < a; i++)
    {
        if (n[i] == '4' || n[i] == '7')
        {
            c = c + 1;
            continue;
        }
        else
        {
            continue;
        }
        
    }
    for (int i = 1; i > 0; i++)
    {
        int x;
        if (c<10)
        {
            if(c == 4 || c == 7){
                cout << "YES";
                break;
            }
            else
            {
                cout << "NO";
                break;
            }
            
        }
        else{
        x = c%10;
        if (x != 4 || x != 7)
            {
                cout << "NO";
                break;
            }
            else{
        c = c/10;}
        }
    }    
    return 0;
}
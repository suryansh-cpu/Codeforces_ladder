#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n[3]={1,2,3};
    for(int value : n)
    {
        cout << value << " ";
    }
    return 0;
}
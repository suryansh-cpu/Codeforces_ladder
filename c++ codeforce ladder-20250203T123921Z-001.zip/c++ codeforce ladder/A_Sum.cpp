#include <bits/stdc++.h>
using namespace std;
int main(){
    int test;
    cin >> test;
    for (int i = 0; i < test; i++)
    {
        int a,b,c;
        cin >> a >> b >> c;
        int maxi=max(a,max(b,c));
        if (maxi==a && a == b+c)
        {
           cout << "YES" << endl;
        }
        else if (maxi==b && b == a+c)
        {
           cout << "YES" << endl;
        }
        else if (maxi==c && c == b+a)
        {
           cout << "YES" << endl;
        }
        else
        {
            cout << "NO" << endl;
        }
        
    }      
    
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int cheak_prime(int num){
   if (num <= 1)
      return 0;
   for (int i = 2; i <= num/2; i++){
      if (num % i == 0)
         { return 0; }
   }
   return 1; //if both failed then num is prime
}
int main(){
    int n;
    cin >> n;
    //int prime[78500]={0};
    // for (int i = 4; i < 78500; i++)
    // {
    //     if(cheak_prime(i))
    //     {
    //         prime[i]=1;
    //     }
    // }
    for (int i = n/2; i < n; i++)
    {
        if (cheak_prime(i)||cheak_prime(n-i))
        {
            continue;
        }
        else
        {
            cout << i << " " << n-i;
            break;
        }        
    }
    
    return 0;
}   
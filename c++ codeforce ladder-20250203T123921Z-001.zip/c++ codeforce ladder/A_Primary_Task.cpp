#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
int firstDigit(int n) 
{ 
    int count=1;
    while (n >= 10) 
    { 
        n /= 10;
        count++;
    }
    return count; 
}
signed main(){
    int test;
    cin >> test;
    for(int i=0;i<test;i++)
    {
        int n;
        cin >> n;
        int count=firstDigit(n);
        int first=count-2;
        int power=pow(10,first);
        int third=count-3;
        third=third%10;
        cout << third;
        // cout << power;
        if(n/power==10)
        {
            if (third>=2)
            {
                cout << "YES" << endl;
            }
            else
            {
                cout << "NO" << endl;
            }
            
        }
        else
        {
            cout << "NO" << endl;
        }
        //cout << count << endl;
    }
    return 0;
}
// #include <iostream>
// #include <cmath>
// using namespace std;

// bool isImportant(int num) {
//     for (int x = 2; ; ++x) {
//         int importantNum = pow(10, x);
//         if (importantNum > num) {
//             break;
//         }
//         int remainder = num - importantNum;
//         if (remainder >= 0 && remainder < importantNum) {
//             return true;
//         }
//     }
//     return false;
// }

// int main() {
//     int t;
//     cin >> t;
//     while (t--) {
//         int a;
//         cin >> a;
//         if (isImportant(a)) {
//             cout << "YES" << endl;
//         } else {
//             cout << "NO" << endl;
//         }
//     }
//     return 0;
// }

#include <bits/stdc++.h>
using namespace std;
int main(){
    int k;
    int r;
    cin >> k >> r;
    for (int i = 1; i > 0; i++)
    {
        int a=k;
        a*=i;
        if (a%10==0 || a%10==r)
        {
            cout << i;
            return 0;
        }
        
    }
     
    return 0;
}
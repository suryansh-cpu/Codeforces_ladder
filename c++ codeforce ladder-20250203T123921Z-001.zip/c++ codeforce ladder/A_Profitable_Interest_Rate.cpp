#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
int ans(int a, int b)
{
    //        time limit exceeding so trying binary search ab

    // while (a<b && a>0)
    // {
    //     a--;
    //     b-=2;
    // }
    // return a;

    int point_one=0;
    int point_two=a;
    int mid;
    while (a<b)
    {
        if((point_one+point_two)%2==0)
        {
            mid=(point_one+point_two)/2;
        }
        else
        {
            mid=(point_one+point_two)/2;
            mid++;
        }
        
        if (mid==point_one || mid==point_two)
        {
            return (a-point_two);
        }
        
        if (a-mid>=b-mid*2)
        {
            point_two=mid;
        }
        else
        {
            point_one=mid;
        }
    }
    

}
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int a,b;
        cin >> a >> b;
        // if(a>=b)
        // {
        //     cout << a << endl;
        // }
        if (a*2>b)
        {
            cout << ans(a,b) << endl;
        }
        else if(a*2<=b)
        {
            cout << "0" << endl;;
        }
        
    }
    
    return 0;
}
#include <bits/stdc++.h>
// #include <conio.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    int mishka=0,chris=0;
    for (int i = 0; i < n; i++)
    {
        int a,b;
        cin >> a >> b;
        // a>b?(mishka++):(chris++);
        if(a>b)
            mishka++;
        else if(b>a)
            chris++;
    }
    mishka>chris?(cout << "Mishka"):(chris>mishka?(cout << "Chris"):(cout << "Friendship is magic!^^"));
    return 0;
}
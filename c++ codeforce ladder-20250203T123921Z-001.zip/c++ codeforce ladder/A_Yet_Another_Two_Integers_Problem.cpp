#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int a,b;
        cin >> a;
        cin >> b;
        int c=max(a,b)-min(a,b);
        if(c==0)
        {
            cout << "0" << "\n";
            continue;
        }
        else
        {
            int count=0;
            count = count+(c/10);
            if (c%10!=0)
            {
                count++;
            }
            cout << count << "\n";
        }
    }
    return 0;
}
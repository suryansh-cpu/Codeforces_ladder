#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n,k;
    cin >> n >> k;
    vector<vector<int>> v( n , vector<int> (n));
    for (int i = 0; i < n; i++)
    {
        for (int j = n-i-1; j >= 0; j--)
        {
            v[i][j]=k;
            break;
        }
        
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << v[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}
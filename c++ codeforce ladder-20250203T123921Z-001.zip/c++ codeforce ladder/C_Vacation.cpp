#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    int max_happiness=0;
    string ans;
    for (int i = 0; i < n; i++)
    {
        int a,b,c;
        cin >> a >> b >> c; 
            if (a>=b && a>=c)
            {
                if(ans=="a")
                {
                    if (b>=c)
                    {
                        max_happiness+=b;
                        ans="b";
                    }
                    else
                    {
                        max_happiness+=c;
                        ans="c";
                    }
                    
                    
                }
                ans="a";
                max_happiness+=a;
            }
            else if(b>=c && b>=a)
            {
                if(ans=="b")
                {
                    if(a>=c)
                    {
                        max_happiness+=a;
                        ans="a";
                    }
                    else
                    {
                        max_happiness+=c;
                        ans="c";
                    }
                    
                }
                else
                {
                    ans="b";
                    max_happiness+=b;
                }
                
            }
            else if(c>=b && c>=a)
            {
                if(ans=="c")
                {
                    if(a>=b)
                    {
                        max_happiness+=a;
                        ans="a";
                    }
                    else
                    {
                        max_happiness+=b;
                        ans="b";
                    }
                    
                }
                else
                {
                    ans="c";
                    max_happiness+=c;
                }
                
            }
    }
    cout << max_happiness;
    return 0;
}
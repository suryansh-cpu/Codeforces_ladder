#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n,k,f,t;
    cin >> n >> k;
    int happiness=0;
    for(int i=0;i<n;i++){
        cin >> f >> t;
        if(t>k)
        if(i==0)
        happiness=f-(t-k);
        else
        if(happiness>=f-(t-k))continue;
        else happiness=f-(t-k);
        else
        if(i==0)
        happiness=f;
        else
        if(happiness>=f)continue;
        else happiness=f;
    }
    cout << happiness;
    return 0;
}
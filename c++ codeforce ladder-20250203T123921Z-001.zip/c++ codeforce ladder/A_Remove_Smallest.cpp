#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        vector <int> v(n);
        for (int j = 0; j < n; j++)
        {
            cin >> v[j];
        }
        sort(v.begin(),v.end());
        for (int j = 0; j < n-1; j++)
        {
            if (v[j+1]-v[j]>1)
            {
                cout << "NO" << "\n";
                goto jump;
            }
            
        }
        cout << "YES" << "\n";
        jump:
        continue;
    }
    
    return 0;
}
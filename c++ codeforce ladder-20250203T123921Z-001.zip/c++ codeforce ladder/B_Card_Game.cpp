#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        int count=0;
        int a=0,b=0,c=0,d=0;
        cin >> a >> b >> c >> d;
        if (a>c && b>d)
        {
            count+=2;            
        }
        else if (a==c && b>d)
        {
            count+=2;            
        }
        else if (a>c && b==d)
        {
            count+=2;            
        }
        if (a>d && b>c)
        {
            count+=2;
        }
        else if (a==d && b>c)
        {
            count+=2;
        }
        else if (a>d && b==c)
        {
            count+=2;
        }
        cout << count << endl;
        
    }
    
    return 0;
}
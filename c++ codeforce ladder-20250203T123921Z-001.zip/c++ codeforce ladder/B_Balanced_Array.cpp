#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
bool odd(int n)
{
    if (n%2==0)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}
void ans(int n)
{
    int o=1;
    cout << "YES" << endl;
    int sum_even=0;
    int sum_odd=0;
    int array[n];
    for (int j = 1; j <= n/2; j++)
    {
        array[j-1]=2*j;
        sum_even+=(2*j);
    }
    int div=n/2;
    div=div+1;
    for (int j = div; j < n; j++)
    {
        if(j==div)
        {
            array[j-1]=o;
            sum_odd+=o;
        }
        else
        {
            o+=2;
            array[j-1]=o;
            sum_odd+=o;
        }
    }
    array[n-1]=sum_even-sum_odd;
    for (int k = 0; k < n; k++)
    {
        cout << array[k] << " ";
    }
    cout << endl;
}
signed main(){
    int test_cases;
    cin >> test_cases;
    for (int i = 0; i < test_cases; i++)
    {
        int n;
        cin >> n;
        if (odd(n/2))
        {
            ans(n);
        }
        else 
        {
            cout << "NO" << endl;
        }
    }
    
    return 0;
}
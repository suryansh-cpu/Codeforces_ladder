#include <iostream>
using namespace std;

int minOccupiedDiagonals(int n, int k) {
    return min(2, min(k, n));
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        cout << minOccupiedDiagonals(n, k) << endl;
    }
    return 0;
}

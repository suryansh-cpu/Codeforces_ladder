#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        vector <int> input(n-1);
        for (int j = 0; j < n-1; j++)
        {
            cin >> input[j];
        }
        vector <int> ans(n);
        for(int k=0;k<n;k++)
        {
            for (int j = 0; j < n; j++)
            {
                if (input[k]&i && input[k+1]&i)
                {
                    ans[k]=i;
                    break;
                }
                
            }
        }
        for (int j = 0; j < n-1; j++)
        {
            cout << ans[j] << " ";
        }
        cout << endl;
    }
    return 0;
}
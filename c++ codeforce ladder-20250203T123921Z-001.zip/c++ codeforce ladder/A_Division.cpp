#include <bits/stdc++.h>
using namespace std;
int main(){
    int test;
    cin >> test;
    for (int i = 0; i < test; i++)
    {
        int number;
        cin >> number;
        if (number<=1399)
        {
            cout << "Division 4" << endl;
            continue;
        }
        else if (number<=1599)
        {
            cout << "Division 3" << endl;
            continue;
        }
        else if (number<=1899)
        {
            cout << "Division 2" << endl;
            continue;
        }
        else if (number>=1900)
        {
            cout << "Division 1" << endl;
            continue;
        }
    }
    
    return 0;
}
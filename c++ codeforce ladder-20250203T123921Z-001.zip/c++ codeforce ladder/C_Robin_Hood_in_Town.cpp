#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int max_wealth=0;
        int sum=0;
        int max_half=0;
        int average=0;
        vector <int> a(n);
        for (int j = 0; j < n; j++)
        {
            cin >> a[j];
            sum+=a[j];
            max_wealth=max(max_wealth,a[j]);
        }
        average=sum/n;
        sort(a.begin(),a.end());
        int mid=n/2 + 1;
        for (int j = 0; j < mid; j++)
        {
            max_half=max(max_half,a[j]);
        }
    }
    
    return 0;
}
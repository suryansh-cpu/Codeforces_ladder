#include <bits/stdc++.h>
using namespace std;
bool cheak(int a)
{
    for (int i = 2; i <= a; i++)
    {
        if (a%i == 0 && a != i)
        {
            return false;
            break;
        }
        else if (a == i)
        {
            return true;
            break;
        }
        else if( a != i)
        {
            continue;
        }
        
    }
    return 0;
}
int main()
{
    int n,m;
    cin >> n >> m;
    cheak(m);
    if (cheak(m) == true)
    {
        int a = n+1;
        for (int i = a; i <= m; i++,a++)       
        {
            cheak(i);
            if (cheak(i) == true && i != m)
            {
                cout << "NO";
                break;
            }
            else if(i == m)
            {
                cout << "YES";
            }
            else if(i != m)
            {
                continue;
            }
        }
    }
    else
    {
        cout << "NO";
    }
    
    
    return 0;
}
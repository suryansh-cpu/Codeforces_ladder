#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    int count=0;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        vector <int> v(n);
        bool bad = false;
        for (int j = 0; j < n; j++)
            cin >> v[j];
        int l=v[0],r=v[0];
        for (int k = 1; k < n; k++)
        {
            if (v[k]==l-1)
            {
                l--;
            }
            else if (v[k]==r+1)
            {
                r++;
            }
            else 
            {
                bad=true;
            }
        }
        cout << (bad ? "NO":"YES") << endl;
    }
    //cout << count;
    return 0;
}
// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;

// signed main() {
//     int t;
//     cin >> t;
//     while (t--) {
//         int n;
//         cin >> n;
//         vector<int> v(n);
//         unordered_set<int> dupli;  // Set to store encountered numbers
        
//         cin >> v[0];
//         dupli.insert(v[0]);  // Insert the first element

//         bool isValid = true;

//         for (int j = 1; j < n; j++) {
//             cin >> v[j];
//             if (dupli.find(v[j] - 1) == dupli.end() && dupli.find(v[j] + 1) == dupli.end()) {
//                 isValid = false;
//                 break;  // Exit early if the condition fails
//             }
//             dupli.insert(v[j]);
//         }

//         if (isValid) {
//             cout << "YES" << endl;
//         } else {
//             cout << "NO" << endl;
//         }
//     }
    
//     return 0;
// }

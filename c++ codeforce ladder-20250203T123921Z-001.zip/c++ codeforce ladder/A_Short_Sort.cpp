#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        string ans;
        cin >> ans;
        if (ans[0]=='a' || ans[1]=='b' || ans[2]=='c')
        {
            cout << "YES" << endl;
        }
        else
        {
            cout << "NO" << endl;
        }
        
    }
    
    return 0;
}
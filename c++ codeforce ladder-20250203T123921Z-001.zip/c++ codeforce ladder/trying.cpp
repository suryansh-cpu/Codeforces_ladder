// // #include<bits/stdc++.h>
// // using namespace std;
// // int main(){
// //     string input;
// //     cin >> input;ṇ
// //     string ans;
// //     for(int i = 0; i < input.length(); i++){
// //         if(input[i] >= 65 && input[i] <= 90){
// //             input[i] = input[i] + 32;
// //         }
// //         if(input[i] == 'a' || input[i] == 'o' || input[i] == 'y' || input[i] == 'e' || input[i] == 'u' || input[i] == 'i'){
// //             continue;
// //         }
// //         else{
// //             ans += '.';
// //             ans += input[i];
// //         }
// //     }
// //     cout << ans << endl;
// //     return 0;
// // }
// // #include<bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //     int n,t;
// //     string s;
// //     cin>>n>>t>>s;
// //     for(int T = 0; T < t; T++)
// //     {
// //         for(int i = 0; i < n; i++)
// //         {
// //             if(s[i]=='G' && s[i+1] == 'B')
// //             {
// //                 swap(s[i],s[i+1]);
// //                 i++;
// //             }
// //         }
// //     }
// //     cout<<s<<endl;
// //     return 0;
// // }
// #include <cmath>
// #include <cstdio>
// #include <vector>
// #include <iostream>
// #include <algorithm>
// using namespace std;


// int main() {
//     /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
//     int n;
//     cin >> n;
//     int queries;
//     cin >> queries;
//     int k;
//     int array[n][k];
//     for (int i=0; i<n; i++) {
//     cin >> k;
//     for(int j=0; j<k; j++)
//     {
//         cin >> array[i][j];
//     }
//     }
//     for(int j=0; j<3; j++)
//     {
//         cout << array[0][j];
//     }
//     // for (int i=0; i<queries; i++) {
//     // int one;
//     // int two;
//     // cin >> one >> two;
//     // cout << array[one][two] << endl;
//     // }
//     return 0;
// }
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a[14] = {4,7,44,47,74,77,444,447,477,744,474,774,777,747};
    if (((n%4==0) || (n%7==0)) || ((n%44==0) || (n%47==0)))
    {
        cout << "YES";
    }
    else if (((n%74==0) || (n%77==0)) || ((n%444==0) || (n%447==0)))
    {
        cout << "YES";
    }
    else if (((n%744==0) || (n%477==0)) || ((n%474==0) || (n%774==0)))
    {
        cout << "YES";
    }
    else if (n%777==0 || n%747==0)
    {
        cout << "YES";
    }
    else{
    cout << "No" << endl;
    }
    return 0;
}
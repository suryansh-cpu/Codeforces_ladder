#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    int k;
    cin >> n;
    cin >> k;
    int time_left=240-k;
    int division=time_left/5;
    // if (division >= n)
    // {
    //     cout << n;
    // }
    // else
    // {
    //     cout << division;
    // }
    int counter=0;
    for (int i = 1; i <= n; i++)
    {
        if (time_left>=i*5)
        {
            time_left-=5*i;
            counter++;
        }
        
    }
    cout << counter;
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int a,b,c,d;
    cin >> a >> b >> c >> d;
    string input;
    cin >> input;
    int n=input.length();
    int sum=0;
    for (int i = 0; i < n; i++)
    {
        if(input[i]==49)
        {
            sum = sum + a;
            // cout << 1;
        }
        else if(input[i]==50)
        {
            sum = sum + b;
        }
        else if(input[i]==51)
        {
            sum = sum + c;
        }
        else if(input[i]==52)
        {
            sum = sum + d;
        }
    }
    cout << sum;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    int a,b,c;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        vector <int> input_array(n);
        //vector <int> answer(2);
        //int a,b,c;
        for (int j = 0; j < n; j++)
        {
            cin >> input_array[j];
        }
        //sort(input_array.begin(),input_array.end());   
        a=input_array[0];
        b=input_array[1];
        if (a!=b)
        {
            if (input_array[2]==a)
            {
                cout << "2" << "\n";
            }
            else if (input_array[2]==b)
            {
                cout << "1" << "\n";
            }
        }
        else if(a==b)
        {
            for (int j = 2; j < n; j++)
            {
                if (input_array[j]!=a)
                {
                    cout << j+1 << "\n";
                    break;
                }
            }
        }
        
    }
    return 0;
}
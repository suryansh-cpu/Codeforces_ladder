#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    int a = 0;
    cin >> n;
    string s;
    cin >> s;
    int length;
    length = s.size();
    for (int i = 0; i < length; i++)
    {
        if (s[i] == s[i+1])
        {
            a = a + 1;
            continue;
        }
        else
        {
            continue;
        }
        
    }
    cout << a;
    return 0;
}
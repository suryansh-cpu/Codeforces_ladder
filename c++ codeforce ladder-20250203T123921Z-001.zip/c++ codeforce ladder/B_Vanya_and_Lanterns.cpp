#include <bits/stdc++.h>
using namespace std;
int main(){
    int lanterns,road_length;
    cin >> lanterns;
    cin >> road_length;
    int arr[lanterns]={0};
    for (int i = 0; i < lanterns; i++)
    {
        cin >> arr[i];
    }
    sort(arr, arr+lanterns);
    double distance=arr[0];
    int end=road_length-arr[lanterns-1];
    if (arr[0]<end)
    {
        distance=end;
    }
    for (int i = 0; i < lanterns-1; i++)
    {
        float d=(arr[i+1]-arr[i]);
        if ((d/2) >= distance)
        {
            distance=d/2;
        }
    }
    cout << fixed << setprecision(10) << distance;
    // for (int i = 0; i < lanterns; i++)
    // {
    //     cout << arr[i];
    // }
    return 0;
}
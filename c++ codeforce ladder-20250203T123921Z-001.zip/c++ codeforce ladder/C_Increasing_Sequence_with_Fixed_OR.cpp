#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
bool isbitset(int x, int s)
{
    int cheak = 1<<s;
    int result = x & cheak;
    return result != 0;
}
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int number=n;
        int arr[65]={0};
        int count=0;
        int k=1;
        for (int j = 0; j < 65; j++)
        {
            if (isbitset(n,j))
            {
                arr[j]=n-pow(2,j);
                count++;
                // n>>1;
            }
            
        }
        cout << count+1 << endl;
        // << " ";
        for (int j = 64; j >= 0; j--)
        {
            if (arr[j]!=0)
            {
            cout << arr[i] << " ";
            }
        }
        cout << n ;
        cout << endl;
    }
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n;
        cin >> n;
        int arr[n]={0};
        int even=0,odd=0;
        int not_on_even=0,not_on_odd=0;;
        for (int j = 0; j < n; j++)
        {
            cin >> arr[j];
            if (arr[j]%2==0)
            {
                even++;
                if (j%2!=0)
                {
                    not_on_even++;
                }
                
            }
            else
            {
                odd++;
                if (j%2==0)
                {
                    not_on_odd++;
                }
                
            }
        }
        if (not_on_even==not_on_odd)
        {
            cout << not_on_even << endl;
        }
        else
        {
            cout << "-1" << endl;
        }
        
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;

signed main() {
    int n;
    cin >> n;
    vector<int> v(n * n);

    for (int i = 0; i < n * n; i++) {
        v[i] = i + 1;
    }

    int j = 0, k = n * n - 1;
    for (int i = 0; i < n; i++) {
        for (int x = 0; x < n / 2; x++, j++) {
            cout << v[j] << " ";
        }
        for (int x = 0; x < n / 2; x++, k--) {
            cout << v[k] << " ";
        }
        cout << endl;
    }

    return 0;
}

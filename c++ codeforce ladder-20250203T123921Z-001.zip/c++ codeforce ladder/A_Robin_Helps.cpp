#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int gold_he_has=0;
        int gold=0;
        int n,k;
        cin >> n >> k;
        for (int j = 0; j < n; j++)
        {
            int a;
            cin >> a;
            if (a==0)
            {
                if (gold_he_has>0)
                {
                    gold++;
                    gold_he_has-=1;
                }
            }
            else if (a>=k)
            {
                gold_he_has+=a;
            }
        }
        cout << gold << endl;
    }
    
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int a,b,c;
        cin >> a >> b >> c;
        if (c>b && b>a)
        {
            cout << "STAIR" << endl;
        }
        else if (c<b && b>a)
        {
            cout << "PEAK" << endl;
        }
        else
        {
            cout << "NONE" << endl;
        }
        
    }
    return 0;
}
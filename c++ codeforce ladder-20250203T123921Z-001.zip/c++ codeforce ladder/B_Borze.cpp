#include <bits/stdc++.h>
using namespace std;
int main()
{
    string code;
    string output;
    int a;
    cin >> code;
    a = code.length();
    for (int i = 0 , j = 0; (i < a && j < a); i++, j++)
    {
        if (code[i] == '.')
        {
            output += '0';
            continue;
        }
        else if (code[i] == '-' && code[i+1] == '.')
        {
            output += '1';
            i = i+1;
            continue;
        }
        else if (code[i] == '-' && code[i+1] == '-')
        {
            output += '2';
            i = i+1;
            continue;
        }
    }
    /*int c;
    c = output.size();
    for (int i = 0; i <= c; i++)
    {
        cout << output[i];
    }
    */
    cout << output;
    return 0;
}
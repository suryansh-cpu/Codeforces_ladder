#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b,c,sum1,sum2,sum3,sum_all;
    cin >> sum1 >> sum2 >> sum3 >> sum_all;
    a = max(sum1,max(sum2,max(sum3,sum_all)));
    if (sum1==a)
    {
        cout << sum1-sum2 << " " << sum1-sum3 << " " << sum1-sum_all;
    }
    else if (sum2==a)
    {
        cout << sum2-sum1 << " " << sum2-sum3 << " " << sum2-sum_all;
    }
    else if (sum3==a)
    {
        cout << sum3-sum2 << " " << sum3-sum1 << " " << sum3-sum_all;
    }
    else if (sum_all==a)
    {
        cout << sum_all-sum2 << " " << sum_all-sum3 << " " << sum_all-sum1;
    }
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++)
    {
    int a;
    cin >> a;
    int b=a/10;
    int c=a-b*10;
    cout << b+c << endl;
    }
    return 0;
}
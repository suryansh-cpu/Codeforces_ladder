#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b;
    cin >> a >> b;
    int count=min(a,b);
    int count1=(max(a,b)-count)/2;
    cout << count << " " << count1;
    return 0;
}
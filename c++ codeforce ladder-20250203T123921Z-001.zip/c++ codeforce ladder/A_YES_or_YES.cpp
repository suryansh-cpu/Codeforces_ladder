#include <bits/stdc++.h>
using namespace std;
int main(){
    int test;
    cin >> test;
    for (int i = 0; i < test; i++)
    {
        string input;
        cin >> input;
        int a,b,c;
        a=input[0];b=input[1];c=input[2];
        if (a == 89 || a == 121)
        {
            if (b == 69 || b == 101)
            {
                if (c == 83 || c == 115)
                {
                    cout << "YES" << "\n";
                }
                else
        {
            cout << "NO" << "\n";
        }
            }
            else
        {
            cout << "NO" << "\n";
        }
        }
        else
        {
            cout << "NO" << "\n";
        }
    }
    return 0;
}
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        int x;
        cin >> x;
        int total_key=0;
        // int m;
        while (x>10)
        {
            total_key+=1;
            x=x/10;
            // cout << x;
        }
        // int sum;
        // int count = total_key-1;
        if (total_key==4)
        {
            total_key+=10;
        }
        if (total_key==3)
        {
            total_key+=6;
        }
        if (total_key==2)
        {
            total_key+=3;
        }
        if (total_key==1)
        {
            total_key++;
        }
        
        total_key=total_key+(10*(x-1))+1;                
        cout << total_key << endl;
    }
    
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a=0,b=0,c=0;
    int x,y,z;
    for (int i = 0; i < n; i++)
    {
        cin >> x >> y >> z;
        a = a + x;
        b = b + y; 
        c = c + z;
    }
    if ((a == 0 && b == 0) && c == 0)
    {
        cout << "YES";
    }
    else {
        cout << "NO";
}
    return 0;
}


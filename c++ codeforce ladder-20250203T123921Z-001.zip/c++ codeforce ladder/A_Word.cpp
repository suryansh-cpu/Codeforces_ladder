#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a;
    int c=0,d=0;
    cin >> a;
    int b;
    b = a.length();
    for (int i = 0; i < b; i++)
    {
        if (a[i] >= 'A' && a[i] <= 'Z')
        {
            c = c + 1;
            continue;
        }
        else if (a[i] >= 'a' && a[i] <= 'z')
        {
            d = d + 1;
            continue;
        }
        
    }
        if (c > d)
        {
            for (int j = 0; j < b; j++)
            {
                if (a[j] >= 'a' && a[j] <= 'z')
                {
                    a[j] = a[j] - 32;
                    continue;
                }
                else 
                {
                    continue;
                }
            }
            cout << a;
        }
        if (c <= d)
        {
            for (int j = 0; j < b; j++)
            {
                if (a[j] >= 'A' && a[j] <= 'Z')
                {
                    a[j] = a[j] + 32;
                    continue;
                }
                else 
                {
                    continue;
                }
            }
            cout << a;
        }
        return 0;
}
/*method 1-->
upper case = x = x-32
lower case = x = x+32
method 2-->
toupper*/
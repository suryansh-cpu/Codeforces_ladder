/*
#include <bits/stdc++.h>
using namespace std;
int small(int l)
{
    int small=0;
    int s[l];
    for (int i = 0; i < l; i++)
    {
        for (int j = i+1; j < l; j++)
        {
            if (s[i] >= s[j])
            {
                break;
            }
            else if (s[i] < s[j] && j != l-1)
            {
                continue;
            }
            if (s[i] < s[j] && j == l-1)
            {
                small = s[i];
                goto jump;
            }
        }
        
    }
    jump: return small;
}
int large(int l)
{
    int large=0;
    int s[l];
    for (int i = 0; i < l; i++)
    {
        for (int j = i+1; j < l-1; j++)
        {
            if (s[i] <= s[j])
            {
                break;
            }
            else if (s[i] > s[j] && j != l-1)
            {
                continue;
            }
            if (s[i] > s[j] && j == l-1)
            {
                large = s[i];
                goto jump;
            }
        }
        
    }
    jump: return large;
}
int main()
{
    int n;
    cin >> n;
    int b = 0;
    int c = 0;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int x;
    x = small(n);
    for (int i = 0; i < n; i++)
    {
        if (a[i] == x)
        {
            for (int j = i; j+1 < n; j++)
            {
                swap(a[j],a[j+1]);
                b = b + 1;
                continue;
            }
            goto here;
        }
        else{
            continue;
        }
        
    }
    //
    int main(){
        int a;
        cin >> a;
        for()
    }
    here:
    int y;
    y = large(n);
    for (int i = n-1; i > 0; i--)
    {
        if (a[i] == y)
        {
            for (int j = i; j >= 0; j--)
            {
            swap(a[j],a[j-1]);
                c = c + 1;
                continue;
            }
            goto there;
        }
        else{
            continue;
        }
        
    }
    there:
    cout << b+c;
    return 0;
}
*/
#include <bits/stdc++.h>
using namespace std;
int small(int n,int array[])
{
    int b = array[n-1];
    for (int i = n-2; i >= 0; i--)
    {
        if (b > array[i])
        {
            b = array[i];
        }
        else
        {
            continue;
        }
    }
    return b;
}
int large(int n,int array[])
{
    int b = array[0];
    for (int i = 1; i < n; i++)
    {
        if (b < array[i])
        {
            b = array[i];
        }
        else
        {
            continue;
        }
        
    }
    return b;
}
int main()
{
    int number=0;
    int n;
    int mini;
    int z;
    int y;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    mini= small(n,a);
    for (int i = 0; i < n; i++)
    {
        if (a[i] == mini)
        {
            z = i;
            break;
        }
        else
        {
            continue;
        }

    }
    // swaping of smallest
    for (int i = z; i < n-1; i++)
    {
        swap(a[i],a[i+1]);
        number = number+1;
    }
    int c = large(n,a);
    for (int j = 0; j < n; j++)
    {
        if (a[j] == c)
        {
            y = j;
        }
        else
        {
            continue;
        }
        
    }
    // cout << z << "\n";
    // cout << y << "\n";
    // swapping of largest
    for (int i = y; i > 0; i--)
    {
        swap(a[i],a[i-1]);
        number = number+1;
    }
    
//    test for printing output for array
   /* for (int i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }*/
    cout << number;
//   ----> test 1 for small
//    cout << "\n" <<small(n,a);
    return 0;
}


// error--> array cannot be passed... pass by reference
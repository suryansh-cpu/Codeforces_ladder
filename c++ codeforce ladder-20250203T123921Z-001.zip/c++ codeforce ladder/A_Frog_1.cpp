                                /*method one*//*this could be correct just use method 2 of doing it backward(n-1 se 0 tak not 0 se n-1)*/

// #include <bits/stdc++.h>
// #define int long long int
// #define endl "\n"
// using namespace std;
// // int ans=0;
// int size=0;
// int t[100002];
// int findMininmumJumpingCost(vector<int> v, int n, int i) {
//     // If we've reached the last point, return 0 as no further jumps are required
//     if(i >= n - 1) {
//         return 0;
//     }
//     if(t[i] != -1){ 
//         return t[i];
//     }
//     t[i] = abs(v[i + 1] - v[i]) + findMininmumJumpingCost(v, n, i + 1);
//     if(i + 2 <= n - 1) {
//         t[i] = min(t[i], abs(v[i + 2] - v[i]) + findMininmumJumpingCost(v, n, i + 2));
//     }    
//     return t[i];
// }
// signed main(){
//     int n;
//     cin >> n;
//     vector <int> v(n);
//     memset(t,-1,sizeof(t));
//     for (int i = 0; i < n; i++)
//     {
//         cin >> v[i];
//     }
//     int d=0;
//     d=findMininmumJumpingCost(v,n,0);

//     cout << d;
//     return 0;
// }

                            /* METHOD 2- also called iterative dp without recursion and its function */  
#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
int size=0;
int t[100002];
signed main(){
    int n;
    cin >> n;
    vector <int> v(n);
    memset(t,-1,sizeof(t));
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    t[n - 1] =0;
    for (int i = n - 2; i > -1; i--) {
        t[i] = t[i +  1] + abs(v[i] - v[i + 1]);
        if(i < n - 2) {
            t[i] = min(t[i], t[i + 2] + abs(v[i] - v[i + 2]));
        }
    }
    cout << t[0];
    return 0;
}
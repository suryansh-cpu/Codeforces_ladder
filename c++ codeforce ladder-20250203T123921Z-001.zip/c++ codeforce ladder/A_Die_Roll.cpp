#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int y,w;
    cin >> y >> w;
    int probability_to_win=0;
    probability_to_win=6-max(y,w)+1;
    if (probability_to_win%2==0)
    {
        if (probability_to_win%6==0)
        {
            cout << "1/1";
        }
        else
        {
            cout << probability_to_win/2 << "/" << "3";
        }
        
    }
    else
    {
        if (probability_to_win==3)
        {
            cout << "1/2";
        }
        else
        {
            cout << probability_to_win << "/" << "6";
        }
        
    }
    
    return 0;
}
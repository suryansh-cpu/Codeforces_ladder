#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    int odd=0;
    int even=0;
    for (int i = 0; i < n; i++)
    {
        int a;
        cin >> a;
        if (a%2==0)
        {
            even++;
        }
        else
        {
            odd++;
        }
        
    }
    if (odd%2==0)
    {
        cout << even;
    }
    else
    {
        cout << odd;
    }
    
    return 0;
}
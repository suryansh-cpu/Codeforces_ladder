#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    if (n == 1 || n%2 != 0)
    {
        cout << "-1";
    }
    else if(n%2 == 0)
    {

        for (int j = n; j >= 1; j--)
        {
            cout << j << " ";
        }
    }
    return 0;
}
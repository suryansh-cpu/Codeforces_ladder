#include <bits/stdc++.h>
#define int long long int
#define endl "\n"
using namespace std;
signed main(){
    int n;
    cin >> n;
    vector <int> v(n);
    fill(v.begin(),v.end(),0);
    for (int i = 0; i < n; i++)
    {
        int a;
        cin >> a;
        v[a] += a;
    }
    sort(v.begin(),v.end());
    for(auto j : v)
    {
        cout << j;
    }
    return 0;
}
// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int n,t;
//     cin >> n >> t;
//     string row;
//     cin >> row;
//     for (int j = t; j > 0; j--)
//     {
//     for (int i = 0; i < n; i++)
//     {
//         if (t != 0)
//         {
//             if (row[i] == 'B' && row[i+1] == 'G')
//             {
//                 swap(row[i],row[i+1]);
//                 i = i+1;
//                 continue;
//             }
//             else if (row[i] == 'G' && row[i+1] == 'B')
//             {
//                 continue;
//             }
//             else if (row[i] == 'B' && row[i+1] == 'B')
//             {
//                 continue;
//             }
//             else if (row[i] == 'G' && row[i+1] == 'G')
//             {
//                 continue;
//             }
            
//         }
//         else if (t == 0)
//         {
//             break;
//         }
//     }
        
//     }
//     cout << row;
//     return 0;
// }
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,t;
    string s;
    cin>>n>>t>>s;
    for(int T = 0; T < t; T++)
    {
        for(int i = 0; i < n; i++)
        {
            if(s[i]=='B' && s[i+1] == 'G')
            {
                swap(s[i],s[i+1]);
                i+=1;
                continue;
            }
        }
    }
    cout<<s<<endl;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,m;
    cin >> n >> m;
    int count=0;
    if (n==1 || m==1)
    {
        cout << "Akshat";
        return 0;
    }
    else
    {
        int i=0;
        int j=0;
        while (i<n && j<m)
        {
            i++;j++;count++;
        }
        
    }
    if (count%2==0)
    {
        cout << "Malvika";
    }
    else
    {
        cout << "Akshat";
    }
    
    return 0;
}